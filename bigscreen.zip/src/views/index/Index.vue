<template>
  <div class="test">
    {{ message }}
  </div>
</template>

<script>
import { fetchList } from '@/api/api'

export default {
  name: 'Index',
  data () {
    return {
      message: 'this is test Axios promise'
    }
  },
  created () {
    this.handlerRuleList()
  },
  methods: {
    handlerRuleList () {
      fetchList().then(res => {
        console.log(res)
      })
    }
  }
}
</script>
