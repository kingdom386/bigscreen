import axios from 'axios'

const baseURL = 'http://192.168.3.26:6126/'
const timeout = 5000

// 创建axios请求实例
const instance = axios.create({
  baseURL,
  timeout
})

// 请求拦截器
instance.interceptors.request.use(config => {
  console.log(config)
  return config
}, error => {
  console.log(error)
})

instance.interceptors.response.use(config => {
  return config
}, error => {
  console.log(error)
})

export default instance
